import io
import pandas as pd
import streamlit as st
import matplotlib.pyplot as plt

st.set_page_config(
    page_title="AI Literacy & Responsible Use Explorer",
    page_icon="📊",
    layout="wide"
)

st.title("AI Literacy & Responsible Use Explorer")
st.caption("A research-support dashboard for real survey responses on generative AI use.")

st.warning(
    "This application does not contain fabricated respondent records. "
    "Upload a CSV exported from your approved questionnaire to view results. "
    "Do not upload names, email addresses, phone numbers, or other direct identifiers."
)

with st.expander("Before uploading data", expanded=True):
    st.markdown("""
    1. Export your Google Forms responses as a CSV file.
    2. Keep a separate, secure copy of the original export.
    3. Remove direct identifiers before uploading.
    4. Use the questionnaire and variable names documented in this repository.
    5. Confirm that your supervisor/institution's requirements for consent and data handling are met.
    """)

uploaded = st.file_uploader("Upload anonymized survey responses (CSV)", type=["csv"])

if uploaded is None:
    st.info("No dataset loaded yet. The dashboard will remain empty until you upload real, anonymized responses.")
    st.subheader("Planned research constructs")
    st.markdown("""
    - AI knowledge / literacy
    - Ethical awareness
    - Academic integrity
    - Responsible generative AI use
    - Background variables (such as respondent group and study level, where collected)
    """)
    st.stop()

try:
    df = pd.read_csv(uploaded)
except Exception as exc:
    st.error(f"Could not read the CSV file: {exc}")
    st.stop()

if df.empty:
    st.error("The uploaded CSV has no rows.")
    st.stop()

st.success(f"Loaded {len(df):,} response rows and {len(df.columns):,} columns.")
st.caption("Check the preview carefully. Counts refer to the uploaded file and are not proof of data quality.")

st.subheader("Data preview")
st.dataframe(df.head(20), use_container_width=True, hide_index=True)

left, right = st.columns(2)
with left:
    st.metric("Rows", f"{len(df):,}")
with right:
    st.metric("Columns", f"{len(df.columns):,}")

st.subheader("Missing-data overview")
missing = df.isna().sum().sort_values(ascending=False)
missing_df = pd.DataFrame({
    "Variable": missing.index,
    "Missing values": missing.values,
    "Missing (%)": (missing.values / len(df) * 100).round(1)
})
st.dataframe(missing_df, use_container_width=True, hide_index=True)

nonempty_missing = missing_df[missing_df["Missing values"] > 0]
if not nonempty_missing.empty:
    st.bar_chart(nonempty_missing.set_index("Variable")["Missing (%)"])
else:
    st.write("No blank cells were detected by pandas in this file.")

st.subheader("Explore a variable")
selected = st.selectbox("Choose a variable", options=list(df.columns))
series = df[selected]
if pd.api.types.is_numeric_dtype(series):
    st.write("Numeric summary")
    st.dataframe(series.describe().to_frame("Value"), use_container_width=True)
    counts = series.dropna().value_counts().sort_index()
else:
    st.write("Category counts")
    counts = series.fillna("(Missing)").astype(str).value_counts()

if not counts.empty:
    st.bar_chart(counts)

st.subheader("Download cleaned copy")
st.caption(
    "This export only trims whitespace from column names and removes fully empty rows. "
    "It does not recode answers, impute missing values, or decide which responses to exclude."
)
cleaned = df.copy()
cleaned.columns = [str(c).strip() for c in cleaned.columns]
cleaned = cleaned.dropna(how="all")
buffer = io.StringIO()
cleaned.to_csv(buffer, index=False)
st.download_button(
    "Download cleaned CSV",
    data=buffer.getvalue().encode("utf-8"),
    file_name="survey_responses_basic_clean.csv",
    mime="text/csv"
)

st.subheader("Research integrity reminders")
st.markdown("""
- Do not describe convenience-sample results as representative of all Patna University members.
- Do not treat self-reported AI literacy as an objective skills test.
- Do not infer causation from a cross-sectional survey.
- Use a documented scoring rule before calculating multi-item construct scores.
- Check item coding and reverse-coded questions before reliability analysis.
- Run Cronbach's alpha, correlations, ANOVA, or regression in SPSS only when justified by the research questions, measurement, assumptions, and sample.
- Report actual sample size, missing data, limitations, and the analyses you really performed.
""")
