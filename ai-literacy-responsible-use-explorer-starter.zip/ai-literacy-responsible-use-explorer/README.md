# AI Literacy & Responsible Use Explorer

A research-support dashboard for a primary-data study of generative AI literacy and responsible use in a university context, with Patna University as the intended research setting.

## Research scope

The project is designed to support a quantitative, cross-sectional questionnaire study involving university students, faculty/teachers, and researchers, subject to supervisor approval and applicable institutional requirements.

Core constructs planned for investigation:

- AI knowledge / literacy
- Ethical awareness
- Academic integrity
- Responsible generative AI use
- Acceptability judgments about different academic uses of GenAI
- Reported practices, including verification of AI-generated information

## Important data policy

This repository does **not** include fabricated survey findings or real participant data. The dashboard starts empty and requires an anonymized CSV exported from the actual questionnaire.

Do not upload names, email addresses, phone numbers, student IDs, or other direct identifiers. Keep the original export secure and follow your supervisor's and institution's data-handling requirements.

## Files

- `app.py` — Streamlit dashboard for uploaded CSV files
- `requirements.txt` — Python dependencies
- `questionnaire_draft.md` — draft questionnaire for supervisor review
- `data_dictionary.csv` — proposed variable definitions and coding
- `analysis_plan.md` — suggested analysis plan for review with the supervisor

## Run locally

1. Install Python.
2. Download or clone this repository.
3. Open a terminal in the repository folder.
4. Install packages:

   ```bash
   pip install -r requirements.txt
   ```

5. Run the app:

   ```bash
   streamlit run app.py
   ```

## Deploy

The app can be deployed using Streamlit Community Cloud by selecting this repository, the `main` branch, and `app.py` as the main file. Do not treat a public deployment as a secure repository for confidential research data. Use the app with anonymized data only.

## Research integrity

This is a technical research-support tool, not a validated psychometric instrument. Questionnaire wording, construct scoring, sampling, consent, and statistical analysis should be reviewed with the project supervisor before data collection. Cross-sectional survey findings support associations, not causal conclusions.
