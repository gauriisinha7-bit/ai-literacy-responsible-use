# Draft Questionnaire: AI Literacy and Responsible Use of Generative AI

**Research setting:** Patna University  
**Target respondent groups:** University students, faculty/teachers, and researchers  
**Study design:** Quantitative, cross-sectional questionnaire (draft for supervisor review)

> This is a draft, not a validated scale. Obtain supervisor approval and follow applicable institutional requirements before distributing it. Do not collect unnecessary identifying information.

## Suggested opening and consent text

You are invited to take part in an academic study about awareness, use, and responsible practices related to generative artificial intelligence (GenAI), such as AI chatbots and text-generation tools. Participation is voluntary. You may skip questions or stop before submitting. Responses will be analyzed for academic purposes and reported in aggregate. Do not enter your name or other identifying details in any free-text response.

**Consent question:** I have read the information above and voluntarily agree to participate.
- Yes, I agree (continue)
- No, I do not agree (end form)

Only use this wording after your supervisor confirms the appropriate consent and data-retention process.

## Section A — Background

1. Respondent group:
   - Student
   - Faculty/Teacher
   - Researcher
   - Prefer not to say / Other (specify only if approved)

2. If student, current level (optional):
   - Undergraduate
   - Postgraduate
   - Doctoral
   - Other
   - Not applicable

3. Broad academic discipline (optional; use categories suitable for the approved sample):
   - Arts/Humanities
   - Social Sciences/Management
   - Science
   - Engineering/Technology
   - Other
   - Prefer not to say

4. Have you used a generative AI tool in the past three months?
   - Yes
   - No
   - Unsure

## Section B — Use of generative AI

5. How often have you used a generative AI tool in the past three months?
   - Never
   - Less than monthly
   - Monthly
   - Weekly
   - Several times a week
   - Daily or almost daily

6. For which purposes have you used GenAI? Select all that apply.
   - Explaining concepts / learning
   - Brainstorming ideas
   - Summarizing material
   - Writing or editing
   - Coding / technical assistance
   - Translation
   - Research support
   - I have not used GenAI
   - Other (optional)

7. In your own work, how often do you verify important GenAI-generated factual claims using another reliable source?
   - Never
   - Rarely
   - Sometimes
   - Often
   - Always
   - Not applicable

## Section C — AI knowledge / literacy

**Suggested response scale for items 8–11:** Strongly disagree / Disagree / Neither agree nor disagree / Agree / Strongly agree / Prefer not to answer.

8. I understand that generative AI can produce incorrect or misleading information.
9. I understand that the quality of a GenAI response can depend on how a prompt is written.
10. I can identify situations in which a GenAI response needs independent verification.
11. I understand that a fluent or confident-sounding AI response is not necessarily accurate.

## Section D — Ethical awareness

Use the same five-point agreement scale.

12. I understand that entering personal or confidential information into an AI tool can create privacy risks.
13. I consider whether AI-generated content may reproduce bias or unfair assumptions.
14. I understand that the use of GenAI may be subject to institutional, course, or workplace rules.
15. I believe users should disclose AI assistance when the applicable rules or context require it.

## Section E — Academic integrity and acceptability judgments

For each scenario, choose one: **Always acceptable / Usually acceptable / Depends on context or rules / Usually unacceptable / Always unacceptable / Not sure**.

16. Using GenAI to brainstorm possible essay topics.
17. Using GenAI to explain a difficult concept, then writing an answer independently.
18. Submitting AI-generated text as one's own work when the task requires independent writing.
19. Using GenAI to edit grammar when the course or supervisor permits it.
20. Including AI-generated references without checking whether the sources actually exist.
21. Using GenAI for research analysis without disclosing it when disclosure is required.

These are scenario judgments, not statements that every institution has the same rules. Keep the wording neutral and ensure scenarios match the study's context.

## Section F — Responsible GenAI practices

**Suggested response scale:** Never / Rarely / Sometimes / Often / Always / Not applicable.

22. I check important AI-generated claims against reliable sources.
23. I revise and critically evaluate AI-generated content before using it.
24. I avoid entering confidential or personally identifying information into public AI tools.
25. I check the relevant academic or institutional rules before using GenAI for assessed work.
26. I disclose AI assistance when required by the applicable rules.
27. I consider whether relying on GenAI could prevent me from developing the skill the task is intended to assess.

## Section G — Optional open-ended question

28. What support, guidance, or training would help members of the university community use GenAI more responsibly? (Optional; please do not include names or identifying details.)

## Notes for the researcher

- Ask the supervisor to review relevance, clarity, burden, and ethics before launch.
- Consider cognitive pretesting or a small pilot, if approved, before full distribution.
- Do not label these draft items a validated scale.
- Define scoring and reverse coding in advance, if applicable.
- Keep acceptability judgments separate from self-reported behaviour; they measure different things.
- Avoid collecting names, emails, student IDs, or exact identifiers unless formally justified and approved.
