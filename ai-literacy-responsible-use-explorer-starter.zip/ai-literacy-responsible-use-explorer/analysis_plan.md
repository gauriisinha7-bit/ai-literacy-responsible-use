# Draft Analysis Plan (for supervisor review)

## Design

Quantitative, cross-sectional survey. The intended population includes Patna University students, faculty/teachers, and researchers. Sampling method and recruitment channels must be specified before collection; do not assume a convenience sample represents the entire university.

## Data preparation

1. Preserve the original export in a secure location.
2. Remove direct identifiers from the analysis copy.
3. Define inclusion/exclusion criteria before inspecting outcomes.
4. Check duplicate submissions only using an approved, privacy-conscious rule.
5. Document missing responses and all recoding decisions.
6. Keep acceptability judgments distinct from actual reported practices.
7. Use the data dictionary so response options are coded consistently.

## Descriptive statistics

- Counts and percentages for categorical variables, including respondent group and usage frequency.
- Means and standard deviations for appropriately scored multi-item measures when justified; otherwise report item-level distributions and medians/interquartile ranges where suitable.
- Missing-data summary for each variable.
- Visualizations should include clear denominators and avoid overstating precision.

## Measurement quality

For multi-item constructs, inspect item distributions and item-total relationships. Cronbach's alpha may be estimated where a set of items is intended to measure one construct. Alpha alone does not prove validity or unidimensionality. Do not combine items into a score until the conceptual basis and scoring rule are justified.

## Association and group comparisons

Potential analyses, only if aligned with hypotheses, sample size, measurement, and assumptions:

- Pearson or Spearman correlation for suitable variable pairs.
- Group comparisons across respondent groups using an appropriate method (for example, ANOVA or a non-parametric alternative, depending on the data and assumptions).
- Regression only with a clearly defined outcome, defensible predictors, adequate sample size, and assumption checks.

## Reporting

Report the actual sample size, recruitment and sampling method, response handling, missing data, measurement limitations, statistical tests, effect sizes where appropriate, and uncertainty. Do not infer causation from cross-sectional data. Avoid claims that the sample represents all Patna University members unless the sampling design supports that claim.

## Software

SPSS is the intended package for the main statistical analysis. The GitHub dashboard is a supplementary tool for data inspection and descriptive visualization, not a replacement for a documented SPSS analysis.
